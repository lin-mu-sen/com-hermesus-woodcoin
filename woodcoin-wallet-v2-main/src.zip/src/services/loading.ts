export const LoadingModal: any = {
  instance: null,
};
