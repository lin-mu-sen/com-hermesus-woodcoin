const Fonts = {
    regular:'Roboto Slab Regular',
    Bold:'Roboto Slab Bold',
    medium:'Roboto Slab Medium',
    Light:'Roboto Slab Light',
    FSPRO:"SF Pro Display Heavy"
}
export default Fonts;