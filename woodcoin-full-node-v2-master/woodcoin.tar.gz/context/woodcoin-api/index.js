const express= require('express')
const app = express()
const port = 3820;
const shellExec = require('shell-exec')
app.listen(port, () => {
  console.log(`Example app listening ${port}`)
});

app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
    command("getbalance "+ req.params.id)
});
app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
});
app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
});
app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
});
app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
});
app.get('/api/balance/:id', function (req, res) {
    res.json({"balance": req.params.id});
});
const { exec } = require("child_process");

app.use(express.urlencoded({
  extended: true
}));

function command(command = "help"){
  exec(`docker exec -it woodcoin-full-node_full_node_1 woodcoin-cli ${command}`, (error, stdout, stderr) => {
    if (error) {
        console.log(`error: ${error.message}`);
        return;
    }
    if (stderr) {
        console.log(`stderr: ${stderr}`);
        return;
    }
    console.log(`stdout: ${stdout}`);
  });
}
function command_1(command = "help"){
  shellExec(command).then(console.log).catch(console.log)
}
command_1()